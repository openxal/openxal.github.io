/*
 * FitAlignDocument.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.net.*;
import java.io.*;
import java.awt.Color;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import java.util.logging.*;
import java.text.*;

import xal.smf.*;
import xal.smf.impl.*;
import xal.extension.application.*;
import xal.extension.smf.application.*;
import xal.extension.bricks.WindowReference;
import xal.extension.widgets.plot.*;
import xal.extension.widgets.swing.*;

/**
 * FitAlignDocument is a custom document for this application.
 * @author  t6p
 */
public class FitAlignDocument extends AcceleratorDocument {
	/** main model */
	final private FitAlignModel MODEL;

	/** plot of the beam orbit */
	private FunctionGraphsJPanel _orbitPlot;


    /** Create a new empty document */
    public FitAlignDocument() {
        this( null );
    }
    
    
    /** 
     * Create a new document loaded from the URL file 
     * @param url The URL of the file to load into the new document.
     */
    public FitAlignDocument( final URL url ) {
		MODEL = new FitAlignModel();

        setSource( url );
    }


    /**
     * Make the main window. This method is called by the superclass to generate the content for this document's main window.
     */
    public void makeMainWindow() {
		final WindowReference windowReference = getDefaultWindowReference( "MainWindow", this );
        mainWindow = (AcceleratorWindow)windowReference.getWindow();

		final JButton measureOrbitButton = (JButton)windowReference.getView( "MeasureOrbitButton" );
		measureOrbitButton.addActionListener( new ActionListener() {
			public void actionPerformed( final ActionEvent event ) {
				if ( getSelectedSequence() != null ) {
					MODEL.measureBeamOrbit();
					clearOrbitPlot();
					plotMeasuredOrbit();
				}
				else {
					displayError( "No Sequence Selected", "You must first select a sequence before measuring the orbit." );
				}
			}
		});

		_orbitPlot = (FunctionGraphsJPanel)windowReference.getView( "OrbitPlot" );
		_orbitPlot.setAxisNameX( "Position from sequence start (m)" );
		_orbitPlot.setAxisNameY( "Beam displacement (mm)" );
		_orbitPlot.setNumberFormatX( new DecimalFormat( "0.00E0" ) );
		_orbitPlot.setNumberFormatY( new DecimalFormat( "0.00E0" ) );

		plotMeasuredOrbit();
	}


    /**
     * Hook for handling the accelerator change event.  Subclasses should override
     * this method to provide custom handling.  The default handler does nothing.
     */
    public void acceleratorChanged() {
		if ( MODEL != null ) {
			MODEL.setSequence( null );
			clearOrbitPlot();
		}
    }


    /**
     * Hook for handling the selected sequence change event.  Subclasses should override
     * this method to provide custom handling.  The default handler does nothing.
     */
    public void selectedSequenceChanged() {
		if ( MODEL != null ) {
			clearOrbitPlot();
			MODEL.setSequence( getSelectedSequence() );
			plotMeasuredOrbit();
		}
    }

    
    /**
     * Save the document to the specified URL.
     * @param url The URL to which the document should be saved.
     */
    public void saveDocumentAs( final URL url ) {
    }


	/** plot the current measured orbit */
	private void plotMeasuredOrbit() {
		final BeamOrbit measuredOrbit = MODEL.getBeamOrbit();
		plotMeasuredOrbit( measuredOrbit );
	}


	/** plot the specified measured orbit */
	private void plotMeasuredOrbit( final BeamOrbit orbit ) {
		plotOrbit( orbit, "Measured", Color.BLUE );
	}


	/** plot the specified orbit */
	private void plotOrbit( final BeamOrbit orbit, final String baseLabel, final Color baseColor ) {
		if ( _orbitPlot != null ) {
			if ( orbit != null ) {
				final List<BPM> bpms = orbit.getBeamPositionMonitors();

				// configure the line properties for the horizontal position series
				final BasicGraphData xOrbitSeries = new BasicGraphData();
				xOrbitSeries.setGraphProperty( _orbitPlot.getLegendKeyString(), baseLabel + " X Orbit" );	// label to display in the legend
				xOrbitSeries.setGraphColor( baseColor.darker() );		// horizontal series is drawn darker than the base color
				xOrbitSeries.setLineDashPattern( 5, 5 );		// dash pattern

				// configure the line properties for the vertical position series
				final BasicGraphData yOrbitSeries = new BasicGraphData();
				yOrbitSeries.setGraphProperty( _orbitPlot.getLegendKeyString(), baseLabel + " Y Orbit" );	// label to display in the legend
				yOrbitSeries.setGraphColor( baseColor.brighter() );		// vertical series is drawn lighter than the base color
				yOrbitSeries.setLineDashPattern( 2, 2 );		// dot pattern

				for ( final BPM bpm : bpms ) {
					// TODO: Get the x, y and z data from the orbit for the bpm and populate the x and y series
				}
				_orbitPlot.addGraphData( xOrbitSeries );
				_orbitPlot.addGraphData( yOrbitSeries );
			}
		}
	}


	/** clear the orbit plot */
	private void clearOrbitPlot() {
		if ( _orbitPlot != null ) {
			_orbitPlot.removeAllGraphData();
		}
	}
}
