/*
 * FitAlignModel.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;


/**
 * FitAlignModel is the main model for the alignment fitting application.
 * @author  t6p
 */
public class FitAlignModel {
	/** accelerator sequence */
	private AcceleratorSeq _sequence;

	/** measured beam orbit */
	private BeamOrbit _beamOrbit;


    /** Create a new model */
    public FitAlignModel() {
		_sequence = null;
		_beamOrbit = null;
    }


	/** get the accelerator sequence */
	public AcceleratorSeq getSequence() {
		return _sequence;
	}


	/** set the accelerator sequence */
	public void setSequence( final AcceleratorSeq sequence ) {
		_sequence = sequence;

		if ( _sequence != null ) {
			measureBeamOrbit();
		}
		else {
			_beamOrbit = null;
		}
	}


	/** get the last measured beam orbit */
	public BeamOrbit getBeamOrbit() {
		return _beamOrbit;
	}


	/** measure the orbit */
	public BeamOrbit measureBeamOrbit() {
		_beamOrbit = BeamOrbit.captureOrbit( _sequence );
		return _beamOrbit;
	}
}
