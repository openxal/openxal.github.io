/*
 * OrbitFitObjective.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;
//import xal.model.probe.*;
//import xal.model.alg.*;
//import xal.model.elem.*;
//import xal.sim.scenario.*;
//import xal.tools.beam.calc.*;
import xal.extension.solver.*;



/**
 * OrbitFitObjective measures how well the trial's orbit fits the measured orbit.
 * @author  t6p
 */
abstract public class OrbitFitObjective extends Objective {
	/** measured beam orbit against which trials will be scored */
	final protected BeamOrbit MEASURED_ORBIT;


	/** constructor */
	protected OrbitFitObjective( final String name, final BeamOrbit measuredOrbit ) {
		super( name );

		MEASURED_ORBIT = measuredOrbit;
	}


	/** create an instance of the orbit fit objective for the horizontal plane */
	static public OrbitFitObjective getHorizontalObjectiveInstance( final BeamOrbit measuredOrbit ) {
		return new HorizontalOrbitFitObjective( measuredOrbit );
	}


	/** create an instance of the orbit fit objective for the vertical plane */
	static public OrbitFitObjective getVerticalObjectiveInstance( final BeamOrbit measuredOrbit ) {
		return new VerticalOrbitFitObjective( measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	abstract public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm );


	public double score( final Trial trial, final BeamOrbit trialOrbit ) {
		// TODO: compute and return the RMS orbit difference between the trialOrbit and MEASURED_ORBIT
	}


	/** calculate the satisfaction for the specified objective value */
	public double satisfaction( final double value ) {
		final double tolerance = 0.1;		// RMS orbit error (millimeters) corresponding to 90% satisfaction
		return SatisfactionCurve.inverseSatisfaction( value, tolerance );
	}
}



/** Orbit Fit Objective for the horizontal coordinate */
class HorizontalOrbitFitObjective extends OrbitFitObjective {
	/** constructor */
	protected HorizontalOrbitFitObjective( final BeamOrbit measuredOrbit ) {
		super( "Horizontal Orbit Fit", measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm ) {
		return orbit.getBeamPositionX( bpm );
	}
}



/** Orbit Fit Objective for the vertical coordinate */
class VerticalOrbitFitObjective extends OrbitFitObjective {
	/** constructor */
	protected VerticalOrbitFitObjective( final BeamOrbit measuredOrbit ) {
		super( "Vertical Orbit Fit", measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm ) {
	return orbit.getBeamPositionY( bpm );
}
}
