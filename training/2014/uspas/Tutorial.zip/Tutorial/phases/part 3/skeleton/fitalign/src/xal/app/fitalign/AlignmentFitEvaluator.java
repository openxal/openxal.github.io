/*
 * AlignmentFitEvaluator.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;
import xal.model.*;
import xal.model.probe.*;
import xal.model.probe.traj.*;
import xal.model.alg.*;
import xal.model.elem.*;
import xal.sim.scenario.*;
import xal.tools.beam.calc.*;
import xal.tools.beam.PhaseVector;
import xal.extension.solver.*;


/**
 * AlignmentFitEvaluator is the evaluator used by the solver to evaluate the alignment fit for a given trial.
 * @author  t6p
 */
public class AlignmentFitEvaluator implements Evaluator {
	/** misaligned quadrupole used in fitting to the measured orbit */
	final private Quadrupole MISALIGNED_QUADRUPOLE;

	/** measured orbit to which to fit */
	final private BeamOrbit MEASURED_ORBIT;

	/** entrance probe */
	final private Probe ENTRANCE_PROBE;

	/** objectives to satisfy */
	final private List<OrbitFitObjective> OBJECTIVES;

	/** horizontal misalignment variable */
	final private Variable X_MISALIGNMENT_VARIABLE;

	/** vertical misalignment variable */
	final private Variable Y_MISALIGNMENT_VARIABLE;

	/** model scenario */
	final private Scenario SCENARIO;


	/** Constructor */
	public AlignmentFitEvaluator( final Quadrupole misalignedQuadrupole, final BeamOrbit measuredOrbit ) {
		MISALIGNED_QUADRUPOLE = misalignedQuadrupole;
		MEASURED_ORBIT = measuredOrbit;

		final AcceleratorSeq sequence = measuredOrbit.getSequence();

		ENTRANCE_PROBE = getProbe( sequence );

		OBJECTIVES = new ArrayList<>();
		// TODO: add the horizontal and vertical OrbitFitObjective objective instances to the OBJECTIVES list

		final double misalignmentAmplitude = 10.0;	// consider up to +/-10 millimeter misalignment range
		// create variables with misalignment in millimeters
		// TODO: assign to X_MISALIGNMENT_VARIABLE and Y_MISALIGNMENT_VARIABLE Variable instances appropriately configured for a misalignment range of +/- 10 millimeters.

		SCENARIO = createScenario( sequence );
	}


	/** create a new problem to solve */
	public Problem newProblem() {
		// TODO: Instantiate and configure the Problem.
	}


	/** get the horizontal misaligment variable */
	public Variable getHorizontallyMisalignedQuadVariable() {
		return X_MISALIGNMENT_VARIABLE;
	}


	/** get the vertical misaligment variable */
	public Variable getVerticallyMisalignedQuadVariable() {
		return Y_MISALIGNMENT_VARIABLE;
	}


	/** create a new scenario */
	static private Scenario createScenario( final AcceleratorSeq sequence ) {
		try {
			final Scenario scenario = Scenario.newScenarioFor( sequence );
			scenario.setSynchronizationMode( Scenario.SYNC_MODE_RF_DESIGN );
			scenario.resync();
			return scenario;
		}
		catch ( Exception exception ) {
			exception.printStackTrace();
			throw new RuntimeException( "Exception instantiating a new model scenario.", exception );
		}
	}


	/** get the probe for the specified sequence */
	static private Probe getProbe( final AcceleratorSeq sequence ) {
		try {
			if ( sequence.isLinear() ) {
				final EnvTrackerAdapt tracker = AlgorithmFactory.createEnvTrackerAdapt( sequence );
				return ProbeFactory.getEnvelopeProbe( sequence, tracker );
			}
			else {
				final TransferMapTracker tracker = AlgorithmFactory.createTransferMapTracker( sequence );
				return ProbeFactory.getTransferMapProbe( sequence, tracker );
			}
		}
		catch( Exception exception ) {
			exception.printStackTrace();
			throw new RuntimeException( "Exception creating new probe.", exception );
		}
	}


	/** copy the entrance probe */
	private Probe copyEntranceProbe() {
		final Probe probe = ENTRANCE_PROBE.copy();
		probe.initialize();
		return probe;
	}


	/** calculate and return the trial orbit given the horizontal and vertical misalignments */
	public BeamOrbit getTrialOrbit( final double xMisalignment, final double yMisalignment ) {
		final Probe probe = copyEntranceProbe();
		SCENARIO.setProbe( probe );

		// collect all the quad elements corresponding to the misaligned quadrupole
		final String misalignedQuadID = MISALIGNED_QUADRUPOLE.getId();
		final List<Element> misalignedQuadElements = new ArrayList<>();
		final Lattice lattice = SCENARIO.getLattice();
		final Iterator<IComponent> componentIter = lattice.globalIterator();
		while( componentIter.hasNext() ) {
			final IComponent component = componentIter.next();
			if ( component instanceof IdealMagQuad ) {
				final IdealMagQuad quadElement = (IdealMagQuad)component;
				final String elementID = quadElement.getId();
				if ( misalignedQuadID.equals( elementID ) ) {
					misalignedQuadElements.add( quadElement );
				}
			}
		}

		// apply the misaligments to the misaligned quadrupole elements
		for ( final Element element : misalignedQuadElements ) {
			element.setAlignX( xMisalignment );
			element.setAlignY( yMisalignment );
		}


		// run the model with the trial misalignments
		try {
			SCENARIO.resyncFromCache();
			SCENARIO.run();
			final Trajectory trajectory = probe.getTrajectory();

			final SimResultsAdaptor simulationAdaptor = new SimpleSimResultsAdaptor( trajectory );

			// calculate the trial orbit
			final BeamOrbit trialOrbit = new BeamOrbit( MEASURED_ORBIT.getSequence() );
			final List<BPM> bpms = MEASURED_ORBIT.getBeamPositionMonitors();
			for ( final BPM bpm : bpms ) {
				final ProbeState state = trajectory.stateForElement( bpm.getId() );
				final PhaseVector coordinates = simulationAdaptor.computeFixedOrbit( state );
				// get the beam position in millimeters
				final double x = 1000 * coordinates.getx();
				final double y = 1000 * coordinates.gety();
				trialOrbit.setBeamPosition( bpm, x, y );
			}

			return trialOrbit;
		}
		catch ( Exception exception ) {
			throw new RuntimeException( "Exception running the model.", exception );
		}
	}


	/** evaluate the trial */
	public void evaluate( final Trial trial ) {
		// get the misaligments from the variables
		final double xMisalignment = trial.getTrialPoint().getValue( X_MISALIGNMENT_VARIABLE ) / 1000.0;	// convert to meters
		final double yMisalignment = trial.getTrialPoint().getValue( Y_MISALIGNMENT_VARIABLE ) / 1000.0;	// convert to meters

		try {
			// calculate the trial orbit for the given misalignments
			// TODO: calculate the orbit for this trial and assign it to a variable named "trialOrbit".

			// store the trial orbit so we can display it later if necessary
			trial.setCustomInfo( trialOrbit );

			// score each objective
			for ( final OrbitFitObjective objective : OBJECTIVES ) {
				final double score = objective.score( trial, trialOrbit );
				trial.setScore( objective, score );
			}
		}
		catch( Exception exception ) {
			trial.vetoTrial( new TrialVeto( trial, null, "Exception: " + exception.getMessage() ) );
		}
	}
}
