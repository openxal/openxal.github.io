/*
 * FitAlignModel.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;


/**
 * FitAlignModelListener is a protocol for handling model events.
 * @author  t6p
 */
public interface FitAlignModelListener {
	/** indicates that the model has found a new fit */
	public void misalignmentFitFound( final FitAlignModel model, final MisalignmentFit fit );

	/** indicates that the solver has stopped */
	public void solverStopped( final FitAlignModel model, final MisalignmentFit fit );
}
