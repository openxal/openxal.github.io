/*
 * FlatOrbitObjective.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;
import xal.extension.solver.*;



/**
 * OrbitFitObjective measures how well the trial's orbit fits the measured orbit.
 * @author  t6p
 */
abstract public class FlatOrbitObjective extends Objective {
	/** measured orbit to which to fit */
	final private BeamOrbit MEASURED_ORBIT;


	/** constructor */
	protected FlatOrbitObjective( final String name, final BeamOrbit measuredOrbit ) {
		super( name );

		MEASURED_ORBIT = measuredOrbit;
	}


	/** create an instance of the flatten orbit objective in the horizontal plane */
	static public FlatOrbitObjective getHorizontalObjectiveInstance( final BeamOrbit measuredOrbit ) {
		return new HorizontalFlattenObjective( measuredOrbit );
	}


	/** create an instance of the flatten orbit objective in the vertical plane */
	static public FlatOrbitObjective getVerticalObjectiveInstance( final BeamOrbit measuredOrbit ) {
		return new VerticalFlattenObjective( measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	abstract public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm );


	/** score the trial orbit for flatness */
	public double score( final Trial trial, final BeamOrbit trialOrbit ) {
		double squareErrorSum = 0.0;
		int count = 0;
		final List<BPM> bpms = trialOrbit.getBeamPositionMonitors();
		// need the correctors to negate the measured orbit (hence want trial orbit to be negative of measured orbit)
		for ( final BPM bpm : bpms ) {
			final double trialPosition = getBeamPositionAt( trialOrbit, bpm );
			final double measuredPosition = getBeamPositionAt( MEASURED_ORBIT, bpm );
			// make sure both trial and measured orbit have a position for the bpm
			if ( !Double.isNaN( trialPosition ) && !Double.isNaN( measuredPosition ) ) {
				final double error = trialPosition + measuredPosition;	// trial orbit should negate measured orbit
				squareErrorSum += error * error;
				++count;
			}
			else {
				trial.vetoTrial( new TrialVeto( trial, null, "No trial for BPM: " + bpm.getId() ) );
				System.err.println( "No trial for BPM: " + bpm.getId() );
			}
		}

		final double rmsError = Math.sqrt( squareErrorSum / count );
//		System.out.println( "Score " + getName() + ": " + rmsError );
		return rmsError;
	}


	/** calculate the satisfaction for the specified objective value */
	public double satisfaction( final double value ) {
		final double tolerance = 0.1;		// RMS orbit error (millimeters) corresponding to 90% satisfaction
		final double satisfaction = SatisfactionCurve.inverseSatisfaction( value, tolerance );
//		System.out.println( "Satisfaction " + getName() + ": " + satisfaction );
		return satisfaction;
	}
}



/** Orbit Fit Objective for the horizontal coordinate */
class HorizontalFlattenObjective extends FlatOrbitObjective {
	/** constructor */
	protected HorizontalFlattenObjective( final BeamOrbit measuredOrbit ) {
		super( "Horizontal Flatten Orbit", measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm ) {
		return orbit.getBeamPositionX( bpm );
	}
}



/** Orbit Fit Objective for the vertical coordinate */
class VerticalFlattenObjective extends FlatOrbitObjective {
	/** constructor */
	protected VerticalFlattenObjective( final BeamOrbit measuredOrbit ) {
		super( "Vertical Flatten Orbit", measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm ) {
	return orbit.getBeamPositionY( bpm );
}
}
