/*
 * AlignmentFitEvaluator.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;
import xal.model.*;
import xal.model.probe.*;
import xal.model.probe.traj.*;
import xal.model.alg.*;
import xal.model.elem.*;
import xal.sim.scenario.*;
import xal.tools.beam.calc.*;
import xal.tools.beam.PhaseVector;
import xal.extension.solver.*;


/**
 * AlignmentFitEvaluator is the evaluator used by the solver to evaluate the alignment fit for a given trial.
 * @author  t6p
 */
public class AlignmentFitEvaluator implements Evaluator {
	/** key to get the alignment fit orbit from the trial's custom info */
	static final public String CUSTOM_INFO_ALIG_FIT_ORBIT_KEY = "alignFitOrbit";

	/** misaligned quadrupole used in fitting to the measured orbit */
	final private Quadrupole MISALIGNED_QUADRUPOLE;

	/** measured orbit to which to fit */
	final private BeamOrbit MEASURED_ORBIT;

	/** entrance probe */
	final private Probe ENTRANCE_PROBE;

	/** objectives to satisfy */
	final private List<OrbitFitObjective> OBJECTIVES;

	/** horizontal misalignment variable */
	final private Variable X_MISALIGNMENT_VARIABLE;

	/** vertical misalignment variable */
	final private Variable Y_MISALIGNMENT_VARIABLE;

	/** model scenario */
	final private Scenario SCENARIO;


	/** Constructor */
	public AlignmentFitEvaluator( final Quadrupole misalignedQuadrupole, final BeamOrbit measuredOrbit ) {
		MISALIGNED_QUADRUPOLE = misalignedQuadrupole;
		MEASURED_ORBIT = measuredOrbit;

		final AcceleratorSeq sequence = measuredOrbit.getSequence();

		ENTRANCE_PROBE = getProbe( sequence );

		OBJECTIVES = new ArrayList<>();
		OBJECTIVES.add( OrbitFitObjective.getHorizontalObjectiveInstance( measuredOrbit ) );
		OBJECTIVES.add( OrbitFitObjective.getVerticalObjectiveInstance( measuredOrbit ) );

		final double misalignmentAmplitude = 10.0;	// consider up to +/-10 millimeter misalignment range
		// create variables with misalignment in millimeters
		X_MISALIGNMENT_VARIABLE = new Variable( "X Alignment", 0.0, -misalignmentAmplitude, misalignmentAmplitude );
		Y_MISALIGNMENT_VARIABLE = new Variable( "Y Alignment", 0.0, -misalignmentAmplitude, misalignmentAmplitude );

		SCENARIO = createScenario( sequence );
	}


	/** create a new problem to solve */
	public Problem newProblem() {
		final Problem problem = new Problem();
		problem.setEvaluator( this );
		problem.addVariable( X_MISALIGNMENT_VARIABLE );
		problem.addVariable( Y_MISALIGNMENT_VARIABLE );

		for ( final Objective objective : OBJECTIVES ) {
			problem.addObjective( objective );
		}

		return problem;
	}


	/** get the horizontal misaligment variable */
	public Variable getHorizontallyMisalignedQuadVariable() {
		return X_MISALIGNMENT_VARIABLE;
	}


	/** get the vertical misaligment variable */
	public Variable getVerticallyMisalignedQuadVariable() {
		return Y_MISALIGNMENT_VARIABLE;
	}


	/** get the variables */
	public List<Variable> getVariables() {
		final List<Variable> variables = new ArrayList<>( 2 );

		variables.add( X_MISALIGNMENT_VARIABLE );
		variables.add( Y_MISALIGNMENT_VARIABLE );

		return variables;
	}


	/** get the objectives */
	public List<Objective> getObjectives() {
		return new ArrayList<Objective>( OBJECTIVES );
	}


	/** create a new scenario */
	static private Scenario createScenario( final AcceleratorSeq sequence ) {
		try {
			final Scenario scenario = Scenario.newScenarioFor( sequence );
			scenario.setSynchronizationMode( Scenario.SYNC_MODE_RF_DESIGN );
			scenario.resync();
			return scenario;
		}
		catch ( Exception exception ) {
			exception.printStackTrace();
			throw new RuntimeException( "Exception instantiating a new model scenario.", exception );
		}
	}


	/** get the probe for the specified sequence */
	static private Probe getProbe( final AcceleratorSeq sequence ) {
		try {
			if ( sequence.isLinear() ) {
				final EnvTrackerAdapt tracker = AlgorithmFactory.createEnvTrackerAdapt( sequence );
				return ProbeFactory.getEnvelopeProbe( sequence, tracker );
			}
			else {
				final TransferMapTracker tracker = AlgorithmFactory.createTransferMapTracker( sequence );
				return ProbeFactory.getTransferMapProbe( sequence, tracker );
			}
		}
		catch( Exception exception ) {
			exception.printStackTrace();
			throw new RuntimeException( "Exception creating new probe.", exception );
		}
	}


	/** copy the entrance probe */
	private Probe copyEntranceProbe() {
		final Probe probe = ENTRANCE_PROBE.copy();
		probe.initialize();
		return probe;
	}


	/** calculate and return the trial orbit given the horizontal and vertical misalignments */
	public BeamOrbit getTrialOrbit( final Scenario scenario, final double xMisalignment, final double yMisalignment ) {
		final Probe probe = copyEntranceProbe();
		SCENARIO.setProbe( probe );

		applyMisaligment( SCENARIO, xMisalignment, yMisalignment );

		// run the model with the trial misalignments
		try {
			SCENARIO.resyncFromCache();
			SCENARIO.run();
			final Trajectory trajectory = probe.getTrajectory();

			final SimResultsAdaptor simulationAdaptor = new SimpleSimResultsAdaptor( trajectory );

			// calculate the trial orbit
			final BeamOrbit trialOrbit = new BeamOrbit( MEASURED_ORBIT.getSequence() );
			final List<BPM> bpms = MEASURED_ORBIT.getBeamPositionMonitors();
			for ( final BPM bpm : bpms ) {
				final ProbeState state = trajectory.stateForElement( bpm.getId() );
				final PhaseVector coordinates = simulationAdaptor.computeFixedOrbit( state );
				// get the beam position in millimeters
				final double x = 1000 * coordinates.getx();
				final double y = 1000 * coordinates.gety();
				trialOrbit.setBeamPosition( bpm, x, y );
			}

			return trialOrbit;
		}
		catch ( Exception exception ) {
			throw new RuntimeException( "Exception running the model.", exception );
		}
	}


	/** get the calculated trial orbit from the trial */
	@SuppressWarnings( "unchecked" )	// suppress cast warning getting customInfo
	static public BeamOrbit getTrialOrbit( final Trial trial ) {
		final Map<String,Object> customInfo = (Map<String,Object>)trial.getCustomInfo();
		return customInfo != null ? (BeamOrbit)customInfo.get( CUSTOM_INFO_ALIG_FIT_ORBIT_KEY ) : null;
	}


	/** calculate and return the trial orbit given the horizontal and vertical misalignments */
	public BeamOrbit getTrialOrbit( final double xMisalignment, final double yMisalignment ) {
		return getTrialOrbit( SCENARIO, xMisalignment, yMisalignment );
	}


	/** apply the specified misalignment to the scenario for the misaligned quadrupole */
	public void applyMisaligment( final Scenario scenario, final double xMisalignment, final double yMisalignment ) {
		// collect all the quad elements corresponding to the misaligned quadrupole
		final String misalignedQuadID = MISALIGNED_QUADRUPOLE.getId();
		final List<IElement> misalignedQuadElements = new ArrayList<>();
		misalignedQuadElements.addAll( SCENARIO.elementsMappedTo( MISALIGNED_QUADRUPOLE ) );

		// apply the misaligments to the misaligned quadrupole elements
		for ( final IElement element : misalignedQuadElements ) {
			final Element quadElement = (Element)element;
			quadElement.setAlignX( xMisalignment );
			quadElement.setAlignY( yMisalignment );
		}
	}


	/** apply the specified misalignment to the scenario for the misaligned quadrupole */
	public void applyMisaligment( final Scenario scenario, final Trial trial ) {
		// get the misaligments from the variables
		final double xMisalignment = trial.getTrialPoint().getValue( X_MISALIGNMENT_VARIABLE ) / 1000.0;	// convert to meters
		final double yMisalignment = trial.getTrialPoint().getValue( Y_MISALIGNMENT_VARIABLE ) / 1000.0;	// convert to meters

		applyMisaligment( scenario, xMisalignment, yMisalignment );
	}


	/** evaluate the trial */
	@SuppressWarnings( "unchecked" )	// suppress cast warning getting customInfo
	public void evaluate( final Trial trial ) {
		// get the misaligments from the variables
		final double xMisalignment = trial.getTrialPoint().getValue( X_MISALIGNMENT_VARIABLE ) / 1000.0;	// convert to meters
		final double yMisalignment = trial.getTrialPoint().getValue( Y_MISALIGNMENT_VARIABLE ) / 1000.0;	// convert to meters

		try {
			// calculate the trial orbit for the given misalignments
			final BeamOrbit trialOrbit = getTrialOrbit( SCENARIO, xMisalignment, yMisalignment );

			// store the trial orbit so we can display it later if necessary
			Map<String,Object> customInfo = (Map<String,Object>)trial.getCustomInfo();
			if ( customInfo == null ) {
				customInfo = new HashMap<>();
				trial.setCustomInfo( customInfo );
			}
			customInfo.put( CUSTOM_INFO_ALIG_FIT_ORBIT_KEY, trialOrbit );

			// score each objective
			for ( final OrbitFitObjective objective : OBJECTIVES ) {
				final double score = objective.score( trial, trialOrbit );
				trial.setScore( objective, score );
			}
		}
		catch( Exception exception ) {
			trial.vetoTrial( new TrialVeto( trial, null, "Exception: " + exception.getMessage() ) );
		}
	}
}
