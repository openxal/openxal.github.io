/*
 * FitAlignModel.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;
import xal.smf.impl.qualify.*;
import xal.model.probe.*;
import xal.model.alg.*;
import xal.model.elem.*;
import xal.sim.scenario.*;
import xal.tools.beam.calc.*;
import xal.tools.dispatch.*;
import xal.extension.solver.*;
import xal.tools.messaging.MessageCenter;


/**
 * FitAlignModel is the main model for the alignment fitting application.
 * @author  t6p
 */
public class FitAlignModel {
	/** message center for dispatching messages to listeners */
	final private MessageCenter MESSAGE_CENTER;

	/** proxy which forwards events to registerd listeners */
	final private FitAlignModelListener EVENT_PROXY;

	/** accelerator sequence */
	private AcceleratorSeq _sequence;

	/** measured beam orbit */
	private BeamOrbit _beamOrbit;

	/** misaligned quadrupole */
	private Quadrupole _misalignedQuad;

	/** solver to perform the fit */
	private Solver _solver;

	/** correctors */
	private final List<Dipole> CORRECTORS;


    /** Create a new model */
    public FitAlignModel() {
		MESSAGE_CENTER = new MessageCenter( "Fit Alignment" );
		EVENT_PROXY = MESSAGE_CENTER.registerSource( this, FitAlignModelListener.class );

		CORRECTORS = new ArrayList<>();

		_sequence = null;
		_beamOrbit = null;
		_misalignedQuad = null;
    }


	/** Add the specified listener as a receiver of ScoreBoard events from this instance. */
	public void addFitAlignModelListener( final FitAlignModelListener listener ) {
		MESSAGE_CENTER.registerTarget( listener, this, FitAlignModelListener.class );
	}


	/** Remove the specified listener from receiving ScoreBoard events from this instance. */
	public void removeFitAlignModelListener( final FitAlignModelListener listener ) {
		MESSAGE_CENTER.removeTarget( listener, this, FitAlignModelListener.class );
	}


	/** get the accelerator sequence */
	public AcceleratorSeq getSequence() {
		return _sequence;
	}



	/** set the accelerator sequence */
	public void setSequence( final AcceleratorSeq sequence ) {
		_sequence = sequence;
		_misalignedQuad = null;

		CORRECTORS.clear();

		if ( _sequence != null ) {
			measureBeamOrbit();

			System.out.println( "Fetching dipoles..." );
			final List<Dipole> correctors = sequence.<Dipole>getNodesOfType( MagnetType.DIPOLE, true );
			System.out.println( "Correctors: " + correctors );
			CORRECTORS.addAll( correctors );

			// always use the setpoint
			for ( Dipole corrector : correctors ) {
				corrector.setUseFieldReadback( false );
			}
		}
		else {
			_beamOrbit = null;
		}
	}


	/** get the correctors */
	public List<Dipole> getCorrectors() {
		return CORRECTORS;
	}


	/** apply the correctors fields for the specified fit */
	public void applyCorrectorFit( final FlattenFit fit ) {
		for ( final Dipole corrector : CORRECTORS ) {
			final String correctorID = corrector.getId();
			final double field = fit.getField( correctorID );
			if ( !Double.isNaN( field ) ) {
				try {
					corrector.setField( field );
				}
				catch( Exception exception ) {
					System.out.println( "Error setting corrector field for corrector: " + correctorID );
					exception.printStackTrace();
				}
			}
		}
	}


	/** get the available quadrupoles */
	public List<Quadrupole> getAvailableQuadrupoles() {
		// grab all the sequence's quadrupoles that have good status
		final AcceleratorSeq sequence = _sequence;
		return sequence != null ? sequence.<Quadrupole>getNodesOfType( Quadrupole.s_strType, true ) : null;
	}


	/** get the misaligned quad */
	public Quadrupole getMisalignedQuad() {
		return _misalignedQuad;
	}


	/** set the misaligned quad */
	public void setMisalignedQuad( final Quadrupole misalignedQuad ) {
		_misalignedQuad = misalignedQuad;
	}


	/** get the last measured beam orbit */
	public BeamOrbit getBeamOrbit() {
		return _beamOrbit;
	}


	/** measure the orbit */
	public BeamOrbit measureBeamOrbit() {
		_beamOrbit = BeamOrbit.captureOrbit( _sequence );
		return _beamOrbit;
	}


	/** calculate and return the trial orbit given the horizontal and vertical misalignments */
	public BeamOrbit getTrialOrbit( final double xMisalignment, final double yMisalignment ) {
		final AlignmentFitEvaluator evaluator = new AlignmentFitEvaluator( _misalignedQuad, _beamOrbit );
		return evaluator.getTrialOrbit( xMisalignment, yMisalignment );
	}


	/** run the misalignment fit */
	public void runMisalignmentFit() {
		System.out.println( "Run the fitting procedure..." );

		// stop any current solvers
		// really need to be more careful about thread safety)
		stopSolving();

		// execute the solver on another queue so the user interface remains responsive
		final DispatchQueue queue = DispatchQueue.getGlobalQueue( DispatchQueue.DISPATCH_QUEUE_PRIORITY_DEFAULT );
		queue.dispatchAsync( new Runnable() {
			public void run() {
				measureBeamOrbit();

				final AlignmentFitEvaluator evaluator = new AlignmentFitEvaluator( _misalignedQuad, _beamOrbit );
				final Problem problem = evaluator.newProblem();

				// run the solver for at least 1 second and at most 60 seconds stopping when the the satisfaciton reaches 99.9%
				final Stopper solverStopper = SolveStopperFactory.minMaxTimeSatisfactionStopper( 1.0, 60.0, 0.999 );
				final Solver solver = new Solver( solverStopper );

				final Variable xMisalignmentVariable = evaluator.getHorizontallyMisalignedQuadVariable();
				final Variable yMisalignmentVariable = evaluator.getVerticallyMisalignedQuadVariable();
				solver.getScoreBoard().addScoreBoardListener( new ScoreBoardListener() {
					/** Indicates that a trial was scored */
					public void trialScored( ScoreBoard scoreboard, Trial trial ) {}

					/** Indicates that a trial was vetoed */
					public void trialVetoed( ScoreBoard scoreboard, Trial trial ) {}

					/** A new optimal solution has been found */
					public void newOptimalSolution( ScoreBoard scoreboard, Trial trial ) {
						final MisalignmentFit fit = new MisalignmentFit( trial, _beamOrbit, xMisalignmentVariable, yMisalignmentVariable );
						EVENT_PROXY.misalignmentFitFound( FitAlignModel.this, fit );
					}
				});

				_solver = solver;
				solver.solve( problem );

				final Trial bestSolution = solver.getScoreBoard().getBestSolution();
				System.out.println( solver.getScoreBoard() );
				System.out.println( bestSolution );

				final MisalignmentFit fit = new MisalignmentFit( bestSolution, _beamOrbit, xMisalignmentVariable, yMisalignmentVariable );
				EVENT_PROXY.solverStopped( FitAlignModel.this, fit );

			}
		});
	}


	/** stop the misalignment fit */
	public void stopMisalignmentFit() {
		System.out.println( "Stop the fitting procedure..." );
		stopSolving();
	}


	/** flatten the orbit */
	public void flattenOrbit() {
		System.out.println( "Run the flattening procedure..." );

		// stop any current solvers
		stopSolving();

		// execute the solver on another queue so the user interface remains responsive
		final DispatchQueue queue = DispatchQueue.getGlobalQueue( DispatchQueue.DISPATCH_QUEUE_PRIORITY_DEFAULT );
		queue.dispatchAsync( new Runnable() {
			public void run() {
				measureBeamOrbit();

				final FlattenEvaluator evaluator = new FlattenEvaluator( _beamOrbit, _misalignedQuad, CORRECTORS );
				final Problem problem = evaluator.newProblem();

				// run the solver for at least 1 second and at most 60 seconds stopping when the the satisfaciton reaches 99.9%
				final Stopper solverStopper = SolveStopperFactory.minMaxTimeSatisfactionStopper( 1.0, 60.0, 0.999 );
				final Solver solver = new Solver( solverStopper );

				solver.getScoreBoard().addScoreBoardListener( new ScoreBoardListener() {
					/** Indicates that a trial was scored */
					public void trialScored( ScoreBoard scoreboard, Trial trial ) {}

					/** Indicates that a trial was vetoed */
					public void trialVetoed( ScoreBoard scoreboard, Trial trial ) {}

					/** A new optimal solution has been found */
					public void newOptimalSolution( ScoreBoard scoreboard, Trial trial ) {
						System.out.println( scoreboard );
						final FlattenFit fit = new FlattenFit( trial, _beamOrbit, evaluator.getCorrectorVariables() );
						EVENT_PROXY.flattenFitFound( FitAlignModel.this, fit );
					}
				});

				_solver = solver;
				System.out.println( "Start the solver..." );
				solver.solve( problem );

				final Trial bestSolution = solver.getScoreBoard().getBestSolution();
				System.out.println( solver.getScoreBoard() );
				System.out.println( bestSolution );

				// post event
				final FlattenFit fit = new FlattenFit( bestSolution, _beamOrbit, evaluator.getCorrectorVariables() );
				EVENT_PROXY.solverStopped( FitAlignModel.this, fit );
			}
		});
	}


	/** stop the misalignment fit */
	public void stopSolving() {
		System.out.println( "Stop the fitting procedure..." );
		// really need to be more careful about thread safety)
		if ( _solver != null ) {
			_solver.stopSolving();
		}
	}
}
