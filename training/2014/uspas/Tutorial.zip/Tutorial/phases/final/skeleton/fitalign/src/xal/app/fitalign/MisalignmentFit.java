/*
 * MisalignmentFit.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import xal.extension.solver.*;


/**
 * MisalignmentFit wraps the misalignment fit information.
 * @author  t6p
 */
public class MisalignmentFit {
	/** trial */
	final private Trial TRIAL;

	/** measured orbit */
	final private BeamOrbit MEASURED_ORBIT;

	/** horizontal misalignment variable */
	final private Variable X_MISALIGNMENT_VARIABLE;

	/** vertical misalignment variable */
	final private Variable Y_MISALIGNMENT_VARIABLE;


	/** Constructor */
	public MisalignmentFit( final Trial trial, final BeamOrbit measuredOrbit, final Variable xMisalignmentVariable, final Variable yMisalignmentVariable ) {
		MEASURED_ORBIT = measuredOrbit;
		TRIAL = trial;
		X_MISALIGNMENT_VARIABLE = xMisalignmentVariable;
		Y_MISALIGNMENT_VARIABLE = yMisalignmentVariable;
	}


	/** get the measured orbit */
	public BeamOrbit getMeasuredOrbit() {
		return MEASURED_ORBIT;
	}


	/** get the trial orbit */
	public BeamOrbit getTrialOrbit() {
		return AlignmentFitEvaluator.getTrialOrbit( TRIAL );
	}


	/** get the horizontal misalignment */
	public double getMisalignmentX() {
		final TrialPoint trialPoint = TRIAL.getTrialPoint();
		return trialPoint.getValue( X_MISALIGNMENT_VARIABLE );
	}


	/** get the vertical misalignment */
	public double getMisalignmentY() {
		final TrialPoint trialPoint = TRIAL.getTrialPoint();
		return trialPoint.getValue( Y_MISALIGNMENT_VARIABLE );
	}


	/** get the satisfaction */
	public double getSatisfaction() {
		return TRIAL.getSatisfaction();
	}
}
