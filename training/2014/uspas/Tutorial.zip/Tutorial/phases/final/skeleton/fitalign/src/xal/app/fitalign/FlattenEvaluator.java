/*
 * FlattenEvaluator.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;
import xal.model.*;
import xal.model.probe.*;
import xal.model.probe.traj.*;
import xal.model.alg.*;
import xal.model.elem.*;
import xal.sim.scenario.*;
import xal.tools.beam.calc.*;
import xal.tools.beam.PhaseVector;
import xal.extension.solver.*;


/**
 * AlignmentFitEvaluator is the evaluator used by the solver to evaluate the alignment fit for a given trial.
 * @author  t6p
 */
public class FlattenEvaluator implements Evaluator {
	/** key to get the flatten orbit from the trial's custom info */
	static final public String CUSTOM_INFO_FLATTEN_ORBIT_KEY = "flattenOrbit";

	/** entrance probe */
	final private Probe ENTRANCE_PROBE;

	/** accelerator sequence */
	final private AcceleratorSeq SEQUENCE;

	/** measured orbit to which to fit */
	final private BeamOrbit MEASURED_ORBIT;

	/** beam position monitors */
	final private List<BPM> BEAM_POSITION_MONITORS;

	/** correctors */
	final private List<Dipole> CORRECTORS;

	/** variables keyed by corrector ID */
	final private Map<String,Variable> CORRECTOR_VARIABLES;

	/** objectives to satisfy */
	final private List<FlatOrbitObjective> OBJECTIVES;

	/** model scenario */
	final private Scenario SCENARIO;


	/** Constructor */
	public FlattenEvaluator( final BeamOrbit measuredOrbit, final Quadrupole misalignedQuad, final List<Dipole> correctors ) {
		SEQUENCE = measuredOrbit.getSequence();
		MEASURED_ORBIT = measuredOrbit;

		BEAM_POSITION_MONITORS = measuredOrbit.getBeamPositionMonitors();

		CORRECTORS = correctors;
		CORRECTOR_VARIABLES = new HashMap<>( correctors.size() );

		ENTRANCE_PROBE = getProbe( SEQUENCE );

		OBJECTIVES = new ArrayList<>();
		OBJECTIVES.add( FlatOrbitObjective.getHorizontalObjectiveInstance( measuredOrbit ) );
		OBJECTIVES.add( FlatOrbitObjective.getVerticalObjectiveInstance( measuredOrbit ) );

		// assign the variables
		for ( final Dipole corrector : correctors ) {
			try {
				final String correctorID = corrector.getId();
				final double lowerLimit = corrector.lowerWarningFieldLimit();
				final double upperLimit = corrector.upperWarningFieldLimit();
				final Variable variable = new Variable( correctorID, corrector.getField(), lowerLimit, upperLimit );
				CORRECTOR_VARIABLES.put( correctorID, variable );
			}
			catch( Exception exception ) {
				System.out.println( "Exception creating variable for corrector: " + corrector.getId() );
				exception.printStackTrace();
			}
		}

		SCENARIO = createScenario( SEQUENCE );
	}


	/** create a new problem to solve */
	public Problem newProblem() {
		final Problem problem = new Problem();

		// TODO: set the evaluator

		// add variables for the orbit flattening
		for ( final Variable variable : CORRECTOR_VARIABLES.values() ) {
			problem.addVariable( variable );
		}

		// TODO: add the objectives

		return problem;
	}


	/** get the corrector variables */
	public Map<String,Variable> getCorrectorVariables() {
		return CORRECTOR_VARIABLES;
	}


	/** create a new scenario */
	static private Scenario createScenario( final AcceleratorSeq sequence ) {
		try {
			final Scenario scenario = Scenario.newScenarioFor( sequence );
			scenario.setSynchronizationMode( Scenario.SYNC_MODE_RF_DESIGN );
			scenario.resync();
			return scenario;
		}
		catch ( Exception exception ) {
			exception.printStackTrace();
			throw new RuntimeException( "Exception instantiating a new model scenario.", exception );
		}
	}


	/** get the probe for the specified sequence */
	static private Probe getProbe( final AcceleratorSeq sequence ) {
		try {
			if ( sequence.isLinear() ) {
				final EnvTrackerAdapt tracker = AlgorithmFactory.createEnvTrackerAdapt( sequence );
				return ProbeFactory.getEnvelopeProbe( sequence, tracker );
			}
			else {
				final TransferMapTracker tracker = AlgorithmFactory.createTransferMapTracker( sequence );
				return ProbeFactory.getTransferMapProbe( sequence, tracker );
			}
		}
		catch( Exception exception ) {
			exception.printStackTrace();
			throw new RuntimeException( "Exception creating new probe.", exception );
		}
	}


	/** copy the entrance probe */
	private Probe copyEntranceProbe() {
		final Probe probe = ENTRANCE_PROBE.copy();
		probe.initialize();
		return probe;
	}


	/** get the calculated trial orbit from the trial */
	@SuppressWarnings( "unchecked" )	// suppress cast warning getting customInfo
	static public BeamOrbit getTrialOrbit( final Trial trial ) {
		final Map<String,Object> customInfo = (Map<String,Object>)trial.getCustomInfo();
		return customInfo != null ? (BeamOrbit)customInfo.get( CUSTOM_INFO_FLATTEN_ORBIT_KEY ) : null;
	}


	/**
	 * Calculate and return the trial orbit given the trial corrector field strengths.
	 * @param correctorFields the map of corrector fields keyed by corrector ID
	 * @return trial orbit given the specified corrector fields
	 */
	public BeamOrbit getTrialOrbit( final Map<String,Double> correctorFields ) {
		final Probe probe = copyEntranceProbe();
		SCENARIO.setProbe( probe );

		// run the model with the trial misalignments
		try {
			SCENARIO.resyncFromCache();

			// apply the trial corrector fields
			for ( final Dipole corrector : CORRECTORS ) {
				final String correctorID = corrector.getId();
				final double field = correctorFields.get( correctorID );
				SCENARIO.setModelInput( corrector, Electromagnet.Property.FIELD.name(), field );
			}

			SCENARIO.run();
			final Trajectory trajectory = probe.getTrajectory();

			final SimResultsAdaptor simulationAdaptor = new SimpleSimResultsAdaptor( trajectory );

			// calculate the trial orbit
			final BeamOrbit trialOrbit = new BeamOrbit( SEQUENCE );
			for ( final BPM bpm : BEAM_POSITION_MONITORS ) {
				// TODO: compute the x and y position in millimeters from the state for the bpm
				trialOrbit.setBeamPosition( bpm, x, y );
			}

			return trialOrbit;
		}
		catch ( Exception exception ) {
			throw new RuntimeException( "Exception running the model.", exception );
		}
	}


	/** evaluate the trial */
	public void evaluate( final Trial trial ) {
		final Map<String,Double> correctorFields = new HashMap<>();

		// populate the corrector fields from the variables
		final TrialPoint trialPoint = trial.getTrialPoint();
		for ( final Dipole corrector : CORRECTORS ) {
			final String correctorID = corrector.getId();
			final Variable variable = CORRECTOR_VARIABLES.get( correctorID );
			// TODO: get the trial's value for the variable and assign it to a local variable named "field"
			correctorFields.put( correctorID, field );
		}

		final Map<String,Object> customInfo = new HashMap<>();
		trial.setCustomInfo( customInfo );

		try {
			// calculate the trial orbit for the given misalignments
			final BeamOrbit trialOrbit = getTrialOrbit( correctorFields );
			customInfo.put( CUSTOM_INFO_FLATTEN_ORBIT_KEY, trialOrbit );

			// score each objective
			for ( final FlatOrbitObjective objective : OBJECTIVES ) {
				final double score = objective.score( trial, trialOrbit );
				trial.setScore( objective, score );
			}
		}
		catch( Exception exception ) {
			System.err.println( "Exception evaluating the flatness trial..." );
			trial.vetoTrial( new TrialVeto( trial, null, "Exception: " + exception.getMessage() ) );
		}
	}
}
