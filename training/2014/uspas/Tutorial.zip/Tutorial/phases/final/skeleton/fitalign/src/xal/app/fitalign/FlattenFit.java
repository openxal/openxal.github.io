/*
 * FlattenFit.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.extension.solver.*;


/**
 * FlattenFit wraps the flatten fit information.
 * @author  t6p
 */
public class FlattenFit {
	/** trial */
	final private Trial TRIAL;

	/** measured orbit */
	final private BeamOrbit MEASURED_ORBIT;

	/** corrector variables */
	final private Map<String,Variable> CORRECTOR_VARIABLES;


	/** Constructor */
	public FlattenFit( final Trial trial, final BeamOrbit measuredOrbit, final Map<String,Variable> correctorVariables ) {
		MEASURED_ORBIT = measuredOrbit;
		TRIAL = trial;
		CORRECTOR_VARIABLES = new HashMap<>( correctorVariables );
	}


	/** get the field for the specified corrector */
	public double getField( final String correctorID ) {
		final Variable variable = CORRECTOR_VARIABLES.get( correctorID );
		if ( variable != null ) {
			return TRIAL.getTrialPoint().getValue( variable );
		}
		else {
			return Double.NaN;
		}
	}


	/** get the measured orbit */
	public BeamOrbit getMeasuredOrbit() {
		return MEASURED_ORBIT;
	}


	/** get the trial orbit */
	public BeamOrbit getTrialOrbit() {
		return FlattenEvaluator.getTrialOrbit( TRIAL );
	}


	/** get the predicted flattened orbit */
	public BeamOrbit getPredictedOrbit() {
		return getMeasuredOrbit().plus( getTrialOrbit()	);
	}


	/** get the satisfaction */
	public double getSatisfaction() {
		return TRIAL.getSatisfaction();
	}
}
