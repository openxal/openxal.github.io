/*
 * FlatOrbitObjective.java
 *
 * Created on January 23, 2014, 1:32 PM
 */

package xal.app.fitalign;

import java.util.*;

import xal.ca.*;
import xal.smf.*;
import xal.smf.impl.*;
import xal.extension.solver.*;



/**
 * OrbitFitObjective measures how well the trial's orbit fits the measured orbit.
 * @author  t6p
 */
abstract public class FlatOrbitObjective extends Objective {
	/** measured orbit to which to fit */
	final private BeamOrbit MEASURED_ORBIT;


	/** constructor */
	protected FlatOrbitObjective( final String name, final BeamOrbit measuredOrbit ) {
		super( name );

		MEASURED_ORBIT = measuredOrbit;
	}


	/** create an instance of the flatten orbit objective in the horizontal plane */
	static public FlatOrbitObjective getHorizontalObjectiveInstance( final BeamOrbit measuredOrbit ) {
		return new HorizontalFlattenObjective( measuredOrbit );
	}


	/** create an instance of the flatten orbit objective in the vertical plane */
	static public FlatOrbitObjective getVerticalObjectiveInstance( final BeamOrbit measuredOrbit ) {
		return new VerticalFlattenObjective( measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	abstract public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm );


	/** score the trial orbit for flatness */
	public double score( final Trial trial, final BeamOrbit trialOrbit ) {
		// TODO implement the score to calculate the RMS orbit error between the measured orbit and the negative of the trial orbit. We want the trial orbit to negate the measured orbit.
	}


	/** calculate the satisfaction for the specified objective value */
	public double satisfaction( final double value ) {
		final double tolerance = 0.1;		// RMS orbit error (millimeters) corresponding to 90% satisfaction
		final double satisfaction = SatisfactionCurve.inverseSatisfaction( value, tolerance );
//		System.out.println( "Satisfaction " + getName() + ": " + satisfaction );
		return satisfaction;
	}
}



/** Orbit Fit Objective for the horizontal coordinate */
class HorizontalFlattenObjective extends FlatOrbitObjective {
	/** constructor */
	protected HorizontalFlattenObjective( final BeamOrbit measuredOrbit ) {
		super( "Horizontal Flatten Orbit", measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm ) {
		return orbit.getBeamPositionX( bpm );
	}
}



/** Orbit Fit Objective for the vertical coordinate */
class VerticalFlattenObjective extends FlatOrbitObjective {
	/** constructor */
	protected VerticalFlattenObjective( final BeamOrbit measuredOrbit ) {
		super( "Vertical Flatten Orbit", measuredOrbit );
	}


	/** get the beam position at the specified beam position monitor */
	public double getBeamPositionAt( final BeamOrbit orbit, final BPM bpm ) {
	return orbit.getBeamPositionY( bpm );
}
}
